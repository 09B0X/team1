package com.team1.controller.moive;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.team1.domain.MovieVO;
import com.team1.service.MovieService;

import lombok.Setter;

@Controller
@RequestMapping("/movie")
public class MovieController {

	@Setter(onMethod_ = @Autowired)
	private MovieService service;
	
	@RequestMapping("/get")
	public void get(@RequestParam("id") Integer id, Model model) {
		MovieVO movie = service.get(id);
		
		model.addAttribute("movie", movie);
	}
}
