package com.team1.mapper;

import com.team1.domain.MovieVO;

public interface MovieMapper {

	public MovieVO read(Integer id);
}
