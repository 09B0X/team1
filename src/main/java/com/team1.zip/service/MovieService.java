package com.team1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.team1.domain.MovieVO;
import com.team1.mapper.MovieMapper;

import lombok.Setter;

@Service
public class MovieService {

	@Setter(onMethod_ = @Autowired)
	private MovieMapper mapper;
	
	
	public MovieVO get(Integer id) {
		return mapper.read(id);
	}
}
