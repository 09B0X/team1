package com.team1.controller.travle;

public class TravleBoardController {
	
	

	// 팀장이 관리하는 repo의 master 브랜치는 항상 잘 동작하는 버전으로 유지
	// 팀장의 master 브랜치에서 작업하면 안됨
	
	// ##
	// 1. 팀원1이 새로운 브랜치(food) 만들어서 작업
	// 2. 팀장이 팀원2의 pull request, confirm, merge, AND 팀원들에게 알림
	// 3. 팀원1은 github / master 브랜치에서 fetchupstream
	// 4. 팀원1은 local / master 브랜치에서 fetch, pull
	// 5. 팀원1은 local / food 브랜치에서 merge master 
	// 6. 팀원1은 local / food 브랜치에서 resolve conflict, commit, push, pull request
	// 7. 팀원1은 github / master에서 food 브랜치 merge 
	// 8. 팀원1은 팀장 master 에 pull request
	
	// 주의: 자주 풀 리퀘하면 팀장이 많은 방해를 받으니
	//      1주일에 날짜 정해서 1~2회 하시면 되겠어요.
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	// 새로운 컨트롤러 작성

	// 제가 작업!!!!!!!
	
	// hesi가 작업하는 줄 몰랐어
	

	//kjk

	// 이게 더빠름
	public static void main(String[] args) {
		
		System.out.println("hello Java");
		System.out.println("*");
		System.out.println("**");
		System.out.println("***");
		System.out.println("****");
		System.out.println("******");
		
	}

}
