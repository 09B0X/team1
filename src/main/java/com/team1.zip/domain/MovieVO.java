package com.team1.domain;

import lombok.Data;

@Data
public class MovieVO {
	private String title;
	private String content;
}
